package com.austin.bookclub.services;
// ...

import com.austin.bookclub.models.Book;
import com.austin.bookclub.repositories.BookRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

@Service
public class BookService {

    // adding the book repository as a dependency
    private final BookRepository bookRepository;

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // returns all the books
    public List<Book> allBooks() {
        return bookRepository.findAll();
    }

    // creates a book
    public Book createBook(Book b) {
        return bookRepository.save(b);
    }

    // retrieves a book
    public Book findBook(Long id) {
        Optional<Book> optionalBook = bookRepository.findById(id);
        if (optionalBook.isPresent()) {
            return optionalBook.get();
        } else {
            return null;
        }
    }

    // updates/creates a book
    public Book updateBook(Book book) {
        return bookRepository.save(book);
    }

    //find by book containing 
    public List<Book> booksContaining(String search) {
        return bookRepository.findByDescriptionContaining(search);
    }

    //delete book
    public void deleteBook(Long id) {
        bookRepository.deleteById(id);
    }

}
